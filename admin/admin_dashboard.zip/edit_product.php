<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}
include 'db_connect.php';

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $query = "SELECT * FROM products WHERE product_id='$id'";
    $result = mysqli_query($conn, $query);
    $product = mysqli_fetch_assoc($result);
}

if (isset($_POST['edit_product'])) {
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $image = mysqli_real_escape_string($conn, $_POST['image']);

    $query = "UPDATE products SET product_name='$name', product_category='$category', product_description='$description', product_image='$image', product_price='$price' WHERE product_id='$id'";
    if (mysqli_query($conn, $query)) {
        header('Location: manage_products.php');
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
</head>
<body>
    <form method="post" action="">
        <input type="hidden" name="id" value="<?php echo $product['product_id']; ?>">
        <label for="name">Product Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $product['product_name']; ?>" required>
        <br>
        <label for="category">Category:</label>
        <input type="text" id="category" name="category" value="<?php echo $product['product_category']; ?>" required>
        <br>
        <label for="description">Description:</label>
        <textarea id="description" name="description" required><?php echo $product['product_description']; ?></textarea>
        <br>
        <label for="price">Price:</label>
        <input type="text" id="price" name="price" value="<?php echo $product['product_price']; ?>" required>
        <br>
        <label for="image">Image URL:</label>
        <input type="text" id="image" name="image" value="<?php echo $product['product_image']; ?>" required>
        <br>
        <button type="submit" name="edit_product">Update Product</button>
    </form>
</body>
</html>
